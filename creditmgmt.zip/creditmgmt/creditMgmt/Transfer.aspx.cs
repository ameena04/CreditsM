﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class Transfer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnects"].ConnectionString);
            con.Open();
            string insert1 = "insert into Transfer_Table (Account_Id,Transferred_To_ID,Transferred_Credit) values(@Account_Id,@Transferred_To_ID,@Transferred_Credit)";
            string insert2 = "UPDATE UserTable SET TransCredit=" + TextBox3.Text + "WHERE Account_Id = " + TextBox1.Text;
            string insert3 = "UPDATE UserTable SET TransCredit=" + TextBox3.Text + "WHERE Account_Id = " + TextBox2.Text;
            string CommandText1 = "UPDATE UserTable SET Current_Point=Current_Point-TransCredit  WHERE Account_Id=" + TextBox1.Text;
            string CommandText2 = "UPDATE UserTable SET Current_Point=Current_Point + TransCredit  WHERE Account_Id=" + TextBox2.Text;

            //Inserting in Transfer Table.
            using (SqlCommand cmd = new SqlCommand(insert1, con))
            {
                cmd.Parameters.AddWithValue("@Account_Id", TextBox1.Text);
                cmd.Parameters.AddWithValue("@Transferred_To_ID", TextBox2.Text);
                cmd.Parameters.AddWithValue("@Transferred_Credit", TextBox3.Text);
                cmd.ExecuteNonQuery();
            }

            //Updating Transfer Credit from credited account in user table.
            using (SqlCommand cmd1 = new SqlCommand(insert2, con))
            {
                cmd1.Parameters.AddWithValue("@TransCredit", TextBox3.Text);
                cmd1.ExecuteNonQuery();
            }

            //Updating Transfer Credit from debited account in user table.
            using (SqlCommand cmd2 = new SqlCommand(insert3, con))
            {
                cmd2.Parameters.AddWithValue("@TransCredit", TextBox3.Text);
                cmd2.ExecuteNonQuery();
            }
            //Updating current points of credited account in user table.
            using (SqlCommand cmd3 = new SqlCommand(CommandText1, con))
            {
                cmd3.ExecuteNonQuery();
            }

            //Updating current points of debited account in user table.
            using (SqlCommand cmd4 = new SqlCommand(CommandText2, con))
            {
                cmd4.ExecuteNonQuery();
            }

            con.Close();
            string message = "Credits transffered successfully.";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "')};";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
        }

        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("Home.aspx", true);
    }
}
